Unpack this zip into the root folder of your game installation. The "installation" part is already done all required files downloaded.
e.g: D:\somefolder\Starfield

In game just press [END] key to bring the DLSS menu. 
You need to turn on FSR2 in the game's settings, because this mod replaces FSR2 with DLSS/XeSS.



REMEMBER: just unzip the contents of this file inside your game root, its all already done, no need to follow the install instructions in the link below.
MOD link: https://www.nexusmods.com/starfield/mods/111