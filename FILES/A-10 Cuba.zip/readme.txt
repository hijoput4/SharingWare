=========================================================================
              INSTRUCTIONS FOR A-10 CUBA! FOR WINDOWS 95,
	     ACTIVISION GAME PREVIEWS and ACTIVISION DEMOS
=========================================================================

-------------------------------------------------------------------------
                    Additions to the A-10 Cuba! Manual
-------------------------------------------------------------------------
1) When inside the A-10 Cuba Shell Screen, you may select game help
by pressing F1. Please note that help is disabled when you are actually
playing network missions or single player missions inside of the 
simulator.

2) Under certain circumstances the preferences for A-10 Cuba! can become
corrupted and cause anomalous behaviors in the game. To fix this problem,
start A-10 Cuba!, select the preferences screen, and then re-select all
of your preferences. Next, quit A-10 Cuba and restart the game. This will
reset the preferences file and fix the problem.


=========================================================================
                   PLAYING THE ACTIVISION PREVIEWS
=========================================================================
To run the game previews included with A-10 Cuba!, you must have a system 
that is capable of displaying 65,000 colors (16 bit color) or higher and
your system must be set to high color in the display properties. In 
addition, you must have a double speed CD Drive (300kps sustained
transfer rate or higher) to correctly play the movies from the CD.

If your video card supports 16 bit color but you get an error message 
telling you that you cannot play the preview movies, please follow the 
steps below.

1) Click on the START button on your taskbar.
2) Select the SETTINGS item and choose CONTROL PANELS.
3) In the CONTROL PANELS folder, double click on DISPLAY.
4) Click on the SETTINGS Tab.
5) Under Color Palette, select HIGH COLOR (16 bit).
6) Click APPLY.

Now, open your CD Rom Drive, double click on Splash.exe and choose
Game Previews.

=========================================================================
              PLAYING THE ACTIVISION DEMOS INCLUDED ON THE CD
=========================================================================
The Activision demos included on the CD have the following 
additional system requirements in addition to those listed on the A-10
Cuba! box:

-------------------------
CD SPEED:
-------------------------
Double-speed CD-ROM drive (300K/bps sustained transfer rate)
for all demos

-------------------------
RAM Requirements
-------------------------
16 Megabytes of RAM for the HyperBlade and Zork Nemesis Demos

-------------------------
Video Card Requirements
-------------------------
16 bit color for the Zork Nemesis Demo

-------------------------
Hard Disk Space
-------------------------

6 Megabytes of uncompressed hard disk space for the Time Commando Demo
8 Megabytes of uncompressed hard disk space for the Zork Nemesis Demo
32 Megabytes of uncompressed hard disk space for the HyperBlade Demo

-------------------------
Compatibility
-------------------------
Please note that the HyperBlade demo will not run properly on some
MMX enhanced and Cyrix sytems. The full version of HyperBlade will
operate correctly on both MMX and Cyrix systems. 

------------
Readme Files
------------
Readme information about each of the demos is contained in its own 
README.TXT file inside the game demo folders on your A-10 Cuba! CD.


